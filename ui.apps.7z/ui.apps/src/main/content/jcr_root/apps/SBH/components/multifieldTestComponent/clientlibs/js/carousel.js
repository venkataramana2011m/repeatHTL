(function($) {
    $(function () {
        $("#bootstrapCarousel").carousel();
    })
})($CQ || jQuery);