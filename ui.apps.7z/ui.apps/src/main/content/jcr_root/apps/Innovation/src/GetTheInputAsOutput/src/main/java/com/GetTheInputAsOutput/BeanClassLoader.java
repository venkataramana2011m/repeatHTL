
package com.GetTheInputAsOutput;

/**
 * Utility class used by script.
 */
public class BeanClassLoader {

    public static String getText() {
        return "Hello World.";
    }
}